package com.example.covid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper myDB;

    private static final int HEART_RATE_CODE = 101;
    private static final int RESPIRATORY_RATE_CODE = 102;
    private static final int LOCATION_ACTIVITY_CODE = 103;

    private static final String DB_PATH = "/data/data/" + BuildConfig.APPLICATION_ID +
            "/databases/" + DatabaseHelper.DATABASE_NAME;
    private static final String PRIVATE_SERVER_UPLOAD_URL = "http://192.168.0.10/upload_file.php";
    private static final String CHARSET = "UTF-8";

    private float heartRate = 0.0f;
    private float respiratoryRate = 0.0f;
    private float longitude = 0.0f;
    private float latitude = 0.0f;
    private TextView HeartText;
    private TextView RespiratoryText;
    private TextView LocationText;

    private long timestamp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDB = new DatabaseHelper(this);

        Date date = new Date();
        timestamp = date.getTime();
        if (!myDB.insertNewRow(timestamp)) {
            Toast.makeText(this, "New Row Creation Failed", Toast.LENGTH_SHORT).show();
        }

        HeartText = (TextView)findViewById(R.id.hearRateText);
        RespiratoryText = (TextView)findViewById(R.id.respiratoryRateText);
        LocationText = (TextView)findViewById(R.id.locationText);

        PrintHeartRate();
        PrintRespiratory();
        displaylocation();
    }

    public void measureHeartRate(View view) {
        Intent intent = new Intent(MainActivity.this, MeasureHeartRate.class);
        startActivityForResult(intent, HEART_RATE_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == HEART_RATE_CODE) {
            heartRate = ((float)data.getIntExtra(Constants.HEART_RATE, 70) *4) / 3;
            PrintHeartRate();
        }

        if (resultCode == RESULT_OK && requestCode == RESPIRATORY_RATE_CODE) {
            respiratoryRate = ((float)data.getIntExtra(Constants.RESPIRATORY_RATE, 20) * 4) / 3;
            PrintRespiratory();
        }

        if (resultCode == RESULT_OK && requestCode == LOCATION_ACTIVITY_CODE) {
            longitude = (float)data.getDoubleExtra(Constants.LONGITUDE, 0.0);
            latitude = (float)data.getDoubleExtra(Constants.LATITUDE, 0.0);
            displaylocation();
        }
    }

    public void measureRespiratoryRate(View view) {
        Intent intent = new Intent(MainActivity.this, MeasureRespiratoryRate.class);
        //myDB.deleteAllRows();
        startActivityForResult(intent, RESPIRATORY_RATE_CODE);
    }

    public void uploadSigns(View view) {
        if(myDB.updateRowMain(timestamp, heartRate, respiratoryRate, longitude, latitude)) {
            Toast.makeText(this, "Signs and Location Upload Successful", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Signs and Location Upload Failed", Toast.LENGTH_SHORT).show();
        }
    }

    public void openLocationActivity(View view) {
        Intent intent = new Intent(MainActivity.this, LocationActivity.class);
        startActivityForResult(intent, LOCATION_ACTIVITY_CODE);
    }

    public void openSymptomsActivity(View view) {
        Intent intent = new Intent(this, SymptomsHandler.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        Bundle bundle = new Bundle();
        bundle.putLong(Constants.TIMESTAMP, timestamp);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void uploadDBToServer(View view) {
        new Thread(() -> {
            try  {
                File uploadFile = new File(DB_PATH);

                MultipartUtil multipart = new MultipartUtil(PRIVATE_SERVER_UPLOAD_URL, CHARSET);
                multipart.addFile("fileUpload", uploadFile);

                List<String> response = multipart.finishRequest();
                for (String line : response) {
                    if (!line.equals("DB Uploaded Successfully to the Server")) {
                        throw new IOException(line);
                    } else {
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, line, Toast.LENGTH_SHORT).show());
                    }
                }
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    private void PrintHeartRate() {
        HeartText.setText(String.format(
                Locale.US, "Heart Rate: %.2f", heartRate));
    }

    private void PrintRespiratory() {
        RespiratoryText.setText(String.format(
                Locale.US, "Respiratory Rate: %.2f", respiratoryRate));
    }

    private void displaylocation() {
        LocationText.setText(String.format(
                Locale.US, "Longitude: %.4f \n Latitude: %.4f", longitude, latitude));
    }
}