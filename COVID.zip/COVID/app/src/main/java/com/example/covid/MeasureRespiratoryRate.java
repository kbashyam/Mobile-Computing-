package com.example.covid;

import android.content.Intent;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;

import java.util.Locale;

public class MeasureRespiratoryRate extends AppCompatActivity {
    private static final int MOVING_AVERAGE_PERIOD = 30;

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private CountDownTimer timer;
    private TextView progressTextView;
    private MovingAverage movingAverage;
    private boolean measuring;
    private SensorEventListener accelerometerListener;
    private Button startCalculationButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_measure_respiratory_rate);

        startCalculationButton = findViewById(R.id.startCalculation);
        progressTextView = (TextView)findViewById(R.id.progressText);
        displayProgress(0);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);

        timer = new CountDownTimer(45000, 1000) {
            int ticker = 0;

            @Override
            public void onTick(long millisUntilFinished) {
                ticker += 1;
                displayProgress(((int) ticker * 100 * 1000) / 45000);
            }

            @Override
            public void onFinish() {
                sensorManager.unregisterListener(accelerometerListener);
                Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(Constants.VIBRATION_DURATION, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(Constants.VIBRATION_DURATION);
                }
                displayProgress(100);
                Intent respiratoryRateData = new Intent();
                respiratoryRateData.putExtra(Constants.RESPIRATORY_RATE, movingAverage.getPeakCount());
                setResult(Activity.RESULT_OK, respiratoryRateData);
                finish();
            }
        };

        accelerometerListener = new SensorEventListener() {
            @Override
            public void onAccuracyChanged(Sensor sensor, int acc) {
                // No need to implement.
            }

            @Override
            public void onSensorChanged(SensorEvent event) {
                double z = event.values[2];
                movingAverage.addData(z);
            }
        };
    }

    @Override
    public void onStop() {
        super.onStop();
        sensorManager.unregisterListener(accelerometerListener);
    }

    public void startCalculation(View view) {
        if (measuring) {
            return;
        }
        measuring = true;
        startCalculationButton.setText("Please wait for the measurement to complete");
        timer.start();
        movingAverage = new MovingAverage(MOVING_AVERAGE_PERIOD);
        sensorManager.registerListener(accelerometerListener, accelerometer,
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    private void displayProgress(int curProgress) {
        progressTextView.setText(String.format(
                Locale.US, "Completion Progress : %s%%", curProgress));
    }
}
